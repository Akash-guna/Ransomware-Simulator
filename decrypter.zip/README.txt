Hey Sucker Use this to retrieve your document

Unzip these files and save it in the same folder as attacked file and then run the decrypt.exe . Dont be smart now it ha no virus.